//
//  ViewController.swift
//  soccerApp
//
//  Created by Paula Viloria on 3/26/23.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if (component == 0) {
        return teams.count;
        }
        else {
        return options.count;
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if (component == 0) {
        teamLabel.text = teams[row]
        return teams[row];
        }
        else {
        optionsLabel.text = options[row]
        return options[row];
        }
    }
    
    //Calls API with any user selected Team-Option combination
    @IBAction func doneButton(_ sender: Any) {
        let map = [
            "Real Madrid 🇪🇸" : 541,
            "FC Barcelona 🇪🇸" : 529,
            "Inter Milan 🇮🇹" : 505,
            "Bayern Munich 🇩🇪" : 157,
            "Chelsea FC 🏴󠁧󠁢󠁥󠁮󠁧󠁿" : 49,
            "Liverpool 🏴󠁧󠁢󠁥󠁮󠁧󠁿" : 40,
            "Manchester United 🏴󠁧󠁢󠁥󠁮󠁧󠁿" : 33
        ]
        
        let team : Int? = map[teams[picker.selectedRow(inComponent: 0)]]
        callAPIWithSelectedCombination(team: team!, userOption: options[picker.selectedRow(inComponent: 1)])
    }
    
  
    @IBOutlet weak var optionsLabel: UILabel!
    @IBOutlet weak var teamLabel: UILabel!
    @IBOutlet weak var picker: UIPickerView!
    
    
    
    var teams: [String] = [];
    var options: [String] = [];

    override func viewDidLoad() {
        super.viewDidLoad()
        teams = ["Real Madrid 🇪🇸", "FC Barcelona 🇪🇸", "Inter Milan 🇮🇹", "Bayern Munich 🇩🇪", "Borussia Dortmund 🇩🇪", "Chelsea FC 🏴󠁧󠁢󠁥󠁮󠁧󠁿", "Liverpool 🏴󠁧󠁢󠁥󠁮󠁧󠁿", "Manchester United 🏴󠁧󠁢󠁥󠁮󠁧󠁿"]
        options = ["Match Schedule", "Team Squads", "Standing"]
        self.picker.delegate = self
        self.picker.dataSource = self
        
    }
    
    func callAPIWithSelectedCombination(team: Int, userOption: String){
        /*var url = URLRequest(url: URL(string: "https://v3.football.api-sports.io/fixtures?season=2020&team=33")!)
         url.addValue("0c37b56adf9cc74824e1be35e36a577c", forHTTPHeaderField: "x-rapidapi-key")
         url.addValue("v3.football.api-sports.io", forHTTPHeaderField: "x-rapidapi-host")
         url.httpMethod = "GET"
         let task = URLSession.shared.dataTask(with: url) { data, response, error in
         if let data = data {
         if let json = try? JSONSerialization.jsonObject(with:
         data, options:[]) as? [String:Double]{
         print(json.values)
         }
         }
         else{
         print(String(describing: error))
         }
         }.resume()
         }
         */
        struct Fixture: Codable {
            
            let goals : goals
        }
        struct goals: Codable{
            let away: Int
            let home: Int
        }
        var semaphore = DispatchSemaphore (value: 0)
        
        var request = URLRequest(url: URL(string: "https://v3.football.api-sports.io/fixtures?season=2020&team=" + String(team))!,timeoutInterval: Double.infinity)
        request.addValue("0c37b56adf9cc74824e1be35e36a577c", forHTTPHeaderField: "x-rapidapi-key")
        request.addValue("v3.football.api-sports.io", forHTTPHeaderField: "x-rapidapi-host")
        
        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
        if let data = data {
        if let json = try? JSONSerialization.jsonObject(with:
        data, options:[]) as? Data{
         //   let first3 = json.prefix(3)
            let response = try? JSONDecoder().decode(Fixture.self, from: json)
           /*for key in first3{
               print(key.value.self)
            }*/
          //  let response = try? JSONDecoder().decode(Fixture.self, from: json)
          //   let fixture = response!.fixture
            print(response)
            
            let jsonData = """
            (
                    {
                    fixture =         {
                        date = "2021-02-09T20:00:00+00:00";
                        id = 605070;
                        periods =             {
                            first = 1612900800;
                            second = 1612904400;
                        };
                        referee = "Javier Alberola";
                        status =             {
                            elapsed = 90;
                            long = "Match Finished";
                            short = FT;
                        };
                        timestamp = 1612900800;
                        timezone = UTC;
                        venue =             {
                            city = Madrid;
                            id = 6669;
                        };
                    };
                    goals =         {
                        away = 0;
                        home = 2;
                    };
                    league =         {
                        country = Spain;
                        flag = "https://media-3.api-sports.io/flags/es.svg";
                        id = 140;
                        logo = "https://media-3.api-sports.io/football/leagues/140.png";
                        name = "La Liga";
                        round = "Regular Season - 1";
                        season = 2020;
                    };
                    score =         {
                        extratime =             {
                            away = "<null>";
                            home = "<null>";
                        };
                        fulltime =             {
                            away = 0;
                            home = 2;
                        };
                        halftime =             {
                            away = 0;
                            home = 0;
                        };
                        penalty =             {
                            away = "<null>";
                            home = "<null>";
                        };
                    };
                    teams =         {
                        away =             {
                            id = 546;
                            logo = "https://media-3.api-sports.io/football/teams/546.png";
                            name = Getafe;
                            winner = 0;
                        };
                        home =             {
                            id = 541;
                            logo = "https://media-2.api-sports.io/football/teams/541.png";
                            name = "Real Madrid";
                            winner = 1;
                        };
                    };
                },
                    {
                    fixture =         {
                        date = "2020-09-20T19:00:00+00:00";
                        id = 605081;
                        periods =             {
                            first = 1600628400;
                            second = 1600632000;
                        };
                        status =             {
                            elapsed = 90;
                            long = "Match Finished";
                            short = FT;
                        };
                        timestamp = 1600628400;
                        timezone = UTC;
                        venue =             {
                            id = 1491;
                            name = "Reale Arena";
                        };
                    };
                    goals =         {
                        away = 0;
                        home = 0;
                    };
                    league =         {
                        country = Spain;
                        flag = "https://media-3.api-sports.io/flags/es.svg";
                        id = 140;
                        logo = "https://media-3.api-sports.io/football/leagues/140.png";
                        name = "La Liga";
                        round = "Regular Season - 2";
                        season = 2020;
                    };
                    score =         {
                        extratime =             {
                            away = "<null>";
                            home = "<null>";
                        };
                        fulltime =             {
                            away = 0;
                            home = 0;
                        };
                        halftime =             {
                            away = 0;
                            home = 0;
                        };
                        penalty =             {
                            away = "<null>";
                            home = "<null>";
                        };
                    };
                    teams =         {
                        away =             {
                            id = 541;
                            logo = "https://media-2.api-sports.io/football/teams/541.png";
                            name = "Real Madrid";
                            winner = "<null>";
                        };
                        home =             {
                            id = 548;
                            logo = "https://media-1.api-sports.io/football/teams/548.png";
                            name = "Real Sociedad";
                            winner = "<null>";
                        };
                    };
                },
                    {
                    fixture =         {
                        date = "2020-09-26T19:00:00+00:00";
                        id = 605088;
                        periods =             {
                            first = 1601146800;
                            second = 1601150400;
                        };
                        referee = "Ricardo De Burgos";
                        status =             {
                            elapsed = 90;
                            long = "Match Finished";
                            short = FT;
                        };
                        timestamp = 1601146800;
                        timezone = UTC;
                        venue =             {
                            city = Sevilla;
                            id = 1489;
                        };
                    };
                    goals =         {
                        away = 3;
                        home = 2;
                    };
                    league =         {
                        country = Spain;
                        flag = "https://media-3.api-sports.io/flags/es.svg";
                        id = 140;
                        logo = "https://media-3.api-sports.io/football/leagues/140.png";
                        name = "La Liga";
                        round = "Regular Season - 3";
                        season = 2020;
                    };
                    score =         {
                        extratime =             {
                            away = "<null>";
                            home = "<null>";
                        };
                        fulltime =             {
                            away = 3;
                            home = 2;
                        };
                        halftime =             {
                            away = 1;
                            home = 2;
                        };
                        penalty =             {
                            away = "<null>";
                            home = "<null>";
                        };
                    };
                    teams =         {
                        away =             {
                            id = 541;
                            logo = "https://media-1.api-sports.io/football/teams/541.png";
                            name = "Real Madrid";
                            winner = 1;
                        };
                        home =             {
                            id = 543;
                            logo = "https://media-3.api-sports.io/football/teams/543.png";
                            name = "Real Betis";
                            winner = 0;
                        };
                    };
                }
"""
        
           /* let jsonData1 = Data(jsonData.utf8)
          let response = try? JSONDecoder().decode(Fixture.self, from: jsonData1)
        //   let fixture = response!.fixture
          print(response)*/
            
           
         
        }
        }
        else{
        print(String(describing: error))
        }
        }.resume()
        
    }
    


}

